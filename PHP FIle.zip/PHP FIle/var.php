<html>
<head>
</head>
<body>
<?php
$x=10;
$y=5;
$z=$x+$y;
echo "sum=",$z;
?>
</body>
</html>