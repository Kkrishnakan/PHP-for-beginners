To fetch the database table data in tabular format
<?php
$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = ''; // Password
$db_name = 'testm'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = 'SELECT * 
		FROM student';
		
$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>
<html>
<head>
	<title>Student table Details</title>
	</head>
<body>
	<table  border='1'>
		<h1>Student Table Details</h1>
		
			<tr>
				<th>SNO</th>
				<th>UNAME</th>
			</tr>
		<?php
		while ($row = mysqli_fetch_array($query))
		{
		echo '<tr>
					<td>'.$row['sno'].'</td>
					<td>'.$row['uname'].'</td>
					
				</tr>';
			}?>
		</table>
</body>
</html>

OR


<html>
<head>
</head>
<body>
  <?php
   $con = mysql_connect("localhost","root","");
   if (!$con)
   {
   die('Could not connect: ' . mysql_error());
   }
   mysql_select_db("testm", $con);
   $result = mysql_query("SELECT * FROM student");
   echo "<table border='1'>
   <tr>
   <th>Sno</th>
    <th>Uname</th>
    </tr>";
    while($row = mysql_fetch_array($result))

    {

    echo "<tr>";
    echo "<td>" . $row['sno'] . "</td>";
    echo "<td>" . $row['uname'] . "</td>";
    echo "</tr>";
    }
    echo "</table>";
    mysql_close($con);

    ?>

</body>

</html>