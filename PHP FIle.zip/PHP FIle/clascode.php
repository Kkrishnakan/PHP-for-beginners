<?php
$str="welcome";
echo "Hello and $str to php";
?>


<?php
$a= 18;
$b= 20;
echo $a+$b;
?>

<?php
$a= 5;
$b= 6;
$txt= "hello";
echo "hello". $a+$b;
?>
----------------------------------
<?php
$a= 5;
$b= 6;
$txt= "hello";
echo $txt . $a+$b;
?>
----------------------------------------
<?php
$a= 5;
$b= 6;
$txt= "hello";
echo $txt;
echo "=";
echo $a+$b;
?>
--------------------------------------
Here's an example script with a function that accesses a global variable:

<?php

$globalName = "Zoe";

function sayHello() {
  $localName = "Harry";
  echo "Hello, $localName!<br>";

  global $globalName;
  echo "Hello, $globalName!<br>";
}

sayHello();

?>

--------------------------------------------
local and global code

<?php
 
$globalName = "Zoe";

function sayHello() {
  $localName = "Harry";
  echo "Hello, $localName!<br>";
}

sayHello();
echo "The value of \$globalName is: '$globalName'<br>";
echo "The value of \$localName is: '$localName'<br>";

?>
op


Hello, Harry!
The value of $globalName is: 'Zoe'
The value of $localName is: ''


------------------------------------------

php assignment operators-- increment operator
<?php
  $var = "value";  // $var now contains the string "value"
  $var = 1;    // $var now contains the integer value 1
  $var += 3;    //$var now contains the integer 4
  echo $var;
?>





<?php
$myVar=3;
$myVar = $myVar-1;
?>



<?php
echo strlen("sslabs"); // outputs 6
?>




<?php
$globalVar = "Harry";
function sslabs() {
  

}
sslabs();
  echo "Hello, $globalVar";
?>

<?php
$x=3+2;
echo $x;

?>


<?php
  
  $var = 1;    // $var now contains the integer value 1
  $var += 3;    //$var now contains the integer 4
  
  echo $var;
?>



<!DOCTYPE html>
         <html>
                <head>
                        <title> PHP Page</title>
                </head>
                <body>
                       <?php
                               PHP code goes here
							   
							   
                       ?>
                </body>
         </html>

		 
		 
		 
		 --control structures----
		 
		 
		 if statements
		 
		  If the condition evaluates to true, then the statement or statements immediately following the condition will be executed. if it is false nothing will executed.
	
syntax:
  if (condition)

           {

                     When condition true code executes;

          }	
<?php
$x=1;

if ($x == 1) 
echo '$x is equal to 1'; 
?>
--------------------------------------
When you have more than one statement to be executed within a control structure, it's necessary to surround them with brackets: 
<?php
$x=1;

if ($x == 1) {
   echo '$x is equal to 1';
   $x++;
   echo 'now $x is equal to 2';
}
?> 
--------------------------------------------------
You can also include multiple conditions within parentheses. For the nested statements to execute, all of the conditions must evaluate to true.

<?php
$x=1;

if ($x == 1 OR $x == 2) 
echo '$x is equal to 1 '; 
?>
-----------------------
Else statements

		 
Else Statements allow you to do something else if the condition within an If Statement evaluated to false


syntax:
 if (condition)

    {
    When condition true code executes;
    }

      else

    {
   When condition false code executes;
    }
<?php
$x=5;

if ($x == 6) {
echo '$x is equal to 6';
} else {
   echo '$x is equal to 5';
} 
?>
----------------------------------------
Else If Statements

if condition is true we will get the output whatever we want
if the if condition false then elseif condtion will execute
if the elseif condition also false then we will go to else condition.

syntax:

  if (condition)

       {
     When condition true code executes; 
        }

      else if (condition)

       { 
      When condition true code executes;
        }

      else

        {

      When all conditions false code executes;
        }

<?php
$x=5;

if ($x == 2) {
echo '$x is equal to 2';
} else if ($x == 1) {
echo '$x is equal to 1';
} else {
   echo '$x does not equal 2 or 1';
}
?>


another ex: based on student marks
<!DOCTYPE html>
       <html>
       <body>
       <?php
 
      $result = 70;
 
       if ($result >= 75) 
 
         { 
       echo "Pass.. Grade A";
             }
       elseif ($result >= 60)
 
          {
       echo "Pass.. Grade B";
           } 
       elseif ($result >= 45)
 
          {
       echo "Pass.. Grade C";
           }
       else
 
           {
       echo "Fail";
		   }
       ?>
      </body>
      </html>
---------------------------------------------------------------------------------
Switches


Switches are a good alternative to If/Else if/Else Statements in situations where you want to check multiple values against a single variable or condition. This is the basic syntax:
		 
		 syntax: 
		 switch(expression){      
          case value1:      
            //code to be executed  
                 break;  
            case value2:      
            //code to be executed  
            break;  
            .....      
           default:       
             code to be executed if all cases are not matched;    
              }  
	 Example

<?php    
$num=20;    
switch($num){    
case 10:    
echo("number is equals to 10");    
break;    
case 20:    
echo("number is equal to 20");    
break;    
case 30:    
echo("number is equal to 30");    
break;    
default:    
echo("number is not equal to 10, 20 or 30");    
}   
?>    
Output:

number is equal to 20	 
		 
		 
		 
		 
		 while
		 ex:
		 
		 $i=3;
		while($i<=6)
		{
		$i++;
		echo "num is" .$i
		}
		
		do_while
		
		
		
		

<?php
$i=0;
		 do
		 {
          echo "number is" . $i;
		 		 $i++;
		 }
		 while($i<=3);
	?>
		
		
		
		 syn:
		 
		 do
		 {
		 
		 }
		 while(con)
		 
		 ex:
		 
		 $i=1;
		 do(
		 $i++;
		 echo "";
		 }
		 while($i<=3);
		 
		 
		 
		 
		 
		 for:
		 syn:
		 
		 for(initialization;condition;increment)
		 {
		 
		 }
		 
		 ex:
		 
		 for($i=1;$i<=3;$i++)
		 {
		 echo "";
		 }
		 
		 
		 
		 
		 
		 
		 
		 foreach($array as $value)
		 {
		 
		 code
		 
		 }
		 
		 
		 ex:
		 $lang=array("telugu","hindi")
		 foreach($array as $val)
		 {
		 echo $val;
		 }
 <?php 
$colors = array("red", "green", "blue", "yellow"); 

foreach ($colors as $value) {
    echo "$value <br>";
}
?>


-----------------------------------------------------------------------------

Arrays:

Array is used to store one or more similar type of values to a single value.
Example if we want to store multi values . so here we take an array to define these multiple values instead of defining all values.


Array Syntax:

$arrayName = array (�value1?,�value2?,�value3?);
-----------------------------------------------------------------
3 types of arrays:

-->Numeric Array
-->Associative Arrays
-->Multidimensional Arrays
 

--------------------------------------
Numeric Array:
it means here an array with numeric key or index.
This is also called as indexed array.
Numeric arrays can store numbers and strings but the array index is represented by numbers.


Example:

<html>
   <body>
   
      <?php
         /* First method to create array. */
         $x = array( 1, 2, 3, 4, 5);
         
         foreach( $x as $value ) {
            echo "value of x is $value <br />";
         }
         
          /* Second method to create array. */
         /* $x[0] = "one";
         $x[1] = "two";
         $x[2] = "three";
         $x[3] = "four";
         $x[4] = "five";
         
         foreach( $x as $value ) {
            echo "Value is $value <br />";
         }  */
      ?>
      
   </body>
</html>

----------------------------------------------------------------------------
Associative Arrays:
 If an array has both index and value then the array is called as Associative array.
 These are same as Numeric Array but here the index is taken as string.
 It means here each key has its own specific value.
 
 Example:Here ram is index and 75 is value
 <html>
   <body>
      
      <?php
         /* First method to associate create array. */
         $marks = array("ram" => 75, "ganesh" => 60, "sri" => 80);
         
         echo "ram marks ". $marks['ram'] . "<br />";
         echo "ganesh marks ".  $marks['ganesh']. "<br />";
         echo "sri marks ".  $marks['sri']. "<br />";
         
         /* Second method to create array. */
         /* $marks['ram'] = "high";
         $marks['ganesh'] = "medium";
         $marks['sri'] = "low";
         
         echo "ram marks ". $marks['ram'] . "<br />";
         echo "ganesh marks ".  $marks['ganesh']. "<br />";
         echo "sri marks ".  $marks['sri']. "<br />"; */
      ?>
   
   </body>
</html>
-------------------------------------------------------------------------------

Multidimensional Arrays:


Here in this array containing one or more arrays within itself.
it means each element in the main array and sub array also an array.
Here in this array we use multiple index.

Example:

<html>
   <body>
      
      <?php
         $marks = array( 
            "ram" => array (
               "English" => 60,
               "Maths" => 65,	
               "Hindi" => 70
            ),
            
            "ganesh" => array (
               "English" => 73,
               "Maths" => 67,
               "Hindi" => 69
            ),
            
            "sri" => array (
               "English" => 80,
               "Maths" => 75,
               "Hindi" => 68
            )
         );
         
         /* Accessing multi-dimensional array values */
         echo "Marks for ram in Hindi : " ;
         echo $marks['ram']['Hindi'] . "<br />"; 
         
         echo "Marks for ganesh in Maths : ";
         echo $marks['ganesh']['Maths'] . "<br />"; 
         
         echo "Marks for sri in English : " ;
         echo $marks['sri']['English'] . "<br />"; 
      ?>
   
   </body>
</html>

------------------------------------------------------------------------
Array functions:


You can see the structure and values of any array by using one of two statements � 
var_dump() or print_r(). --->these two are part of array functions.

 print_r():  It gives less information 
 Example:
 
<?php
// Define array
$languages = array("Telugu", "Hindi", "English");
 
// Display the languages array
print_r($languages);
?>



output:

Array ( [0] => Telugu [1] => Hindi [2] => English )



This output shows the key and the value for each element in the array.

Here Telugu is element

---------------------------------------------------------------------
var_dump() : It gives more information.

Example:

<?php
// Define array
$languages = array("Telugu", "Hindi");
 
// Display the languages array
var_dump($languages);
?>

output:

array(2) { [0]=> string(6) "Telugu" [1]=> string(5) "Hindi" }




This output shows the data type of each element, such as a string of 6 characters, in addition to the key and value.
--------------------------------------------------------------------------------------------------






MySql:

---> To create student table

CREATE TABLE student(
sno INT( 6 ) ,
firstname VARCHAR( 30 ) ,
lastnameCHAR( 10 ) ,
phno INT( 10 ) ,
jdate DATE
)

---> creating a table with rows from another table:

create table student1 as select * from student;

---> To Alter student table

To add new column in table

ALTER TABLE student
  ADD address varchar(40) 
    AFTER lastname;
---------------------------------------------------------------------------

To modify the column like data type,size
 
 alter table student modify lastname varchar(20);
------------------------------------------------------------------------------
The drop clause : removes a column from a table

ALTER TABLE student DROP COLUMN lastname;
output:
the lastname column will be dropped
------------------------------------------------------------
The Rename clause :
to rename table name:

rename oldtablename to newtablename;
 
To rename or change column name:

ALTER TABLE  `student` CHANGE COLUMN  `phno`  `phoneno` INT( 10 ) ;
--------------------------------------------------------------------------------------
Drop Command: used to drop table

DROP TABLE student1;	
-----------------------------------------------
Truncate command:

used to remove all rows from a table without rmoving the structure unlike drop table command.
when using truncate you cannot rollback the data

Ex :  TRUNCATE TABLE student1;
------------------------------------------------------------------------------------------------------

DML:

insert command
	
	ex : INSERT INTO student(sno, firstname, lastname, phno, jdate)
VALUES (1,'rahul', 'kk', 12345,'2018-03-29')

---------------------------------------------------------------------------------	
UPDATE COMMAND:

TO CHANGE EXISTING VALUES IN TABLE:
 
 UPDATE student1 SET phno =23456
 UPDATE student1 SET phno =23456 where sno=2;
 
 
 -----------------------------------------------------------------------------------------
Delete command:
delete from student1;


----------------------------------------------------------------------------------------------

Array Functions:

Count: display no.of elements in the array.
sy:count(array)
Ex: <?php
$language=array("Telugu","Hindi","English","Kannada");
echo count($language);
?>
op:4
---------------------------------------------------------------------------------
sizeof:Also display no.of elements in the array.alias of count it means same as count function.
syn: sizeof(array)
Ex: <?php
$language=array("Telugu","Hindi","English","Kannada");
echo sizeof($language);
?>
---------------------------------------------------------------------------------
array_sum: it display sum of all values in array.
syn:array_sum(arayname)
Ex: <?php
$x = array(3, 4, 5, 6, 8);
echo "sum(x) = " . array_sum($a) . "\n";

$y = array("a" => 1.3, "b" => 3.4, "c" => 5.6);
echo "sum(y) = " . array_sum($b) . "\n";
?>
op : sum(x) = 26 sum(y) = 10.3
---------------------------------------------------------------------------
array_product: It display multiplication of all values in array.
sy: array_product(arrayname)
Ex:  <?php
$a = array(1, 2, 3, 4);
echo "product(a) = " . array_product($a) ;
?>
op : product(a) = 24
------------------------------------------------------------------------------
array_intersect : it display common values between two arrays.
sy: array_intersect(array1,array2)
Ex : <?php
$array1 = array("a" => "Telugu", "Hindi", "English");
$array2 = array("b" => "Telugu", "Hindi", "Kannada");
$result = array_intersect($array1, $array2);
print_r($result);
?>
op: Array ( [a] => Telugu [0] => Hindi )
--------------------------------------------------------------------------
array_diff : It display the different values in arrays.
sy : array_diff(array1,array2)
Ex:  <?php
$array1 = array("a" => "Telugu", "Hindi", "English");
$array2 = array("b" => "Telugu", "Hindi", "Kannada");
$result = array_diff($array1, $array2);
print_r($result);
?>
op : Array ( [1] => English )
------------------------------------------------------------------------
array_merge : It will combine two arrays into one array.
sy : array_merge(array1,array2)
Ex : <?php
$array1 = array("a" => "Telugu", "Hindi", "English");
$array2 = array("b" => "Telugu", "Hindi", "Kannada");
$result = array_merge($array1, $array2);
print_r($result);
?>
op : Array ( [a] => Telugu [0] => Hindi [1] => English [b] => Telugu [2] => Hindi [3] => Kannada )
---------------------------------------------------------------------------------------------

Math Functions :
abs :  Absolute value
Ex : <?php
echo abs(-6.3); // 6.3 (double/float)
echo abs(8);    // 8 (integer)
echo abs(-8);   // 8 (integer)
?>
-------------------------------------------------------------------------------------------------------
min : 
<?php
echo min(8, 6, 5, 4, 3);  // 3
echo min(array(3, 8, 6)); // 3
?>
------------------------------------------------------------------------------------
max : 
<?php
echo max(8, 6, 5, 4, 3);  // 1
echo max(array(3, 8, 6)); // 2
?>
-------------------------------------------------------------------------------------
sin : 
<?php
echo sin(90);
?>
--------------------------------------------
cos :
tan :
sqrt :
<?php
echo sqrt(4);
?>
op : 2
---------------------------------------------------------
pow: To get the power of the input values.
<?php
echo pow(3,2);
?>
op : 9
---------------------------------------------------------
To fetch the database table data in tabular format
<?php
$db_host = 'localhost'; // Server Name
$db_user = 'root'; // Username
$db_pass = ''; // Password
$db_name = 'testm'; // Database Name

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
if (!$conn) {
	die ('Failed to connect to MySQL: ' . mysqli_connect_error());	
}

$sql = 'SELECT * 
		FROM student';
		
$query = mysqli_query($conn, $sql);

if (!$query) {
	die ('SQL Error: ' . mysqli_error($conn));
}
?>
<html>
<head>
	<title>Student table Details</title>
	</head>
<body>
	<table  border='1'>
		<h1>Student Table Details</h1>
		
			<tr>
				<th>SNO</th>
				<th>UNAME</th>
			</tr>
		<?php
		while ($row = mysqli_fetch_array($query))
		{
		echo '<tr>
					<td>'.$row['sno'].'</td>
					<td>'.$row['uname'].'</td>
					
				</tr>';
			}?>
		</table>
</body>
</html>

second method:
<html>
<head>
</head>
<body>
  <?php
   $con = mysql_connect("localhost","root","");
   if (!$con)
   {
   die('Could not connect: ' . mysql_error());
   }
   mysql_select_db("testm", $con);
   $result = mysql_query("SELECT * FROM student");
   echo "<table border='1'>
   <tr>
   <th>Sno</th>
    <th>Uname</th>
    </tr>";
    while($row = mysql_fetch_array($result))

    {

    echo "<tr>";
    echo "<td>" . $row['sno'] . "</td>";
    echo "<td>" . $row['uname'] . "</td>";
    echo "</tr>";
    }
    echo "</table>";
    mysql_close($con);

    ?>

</body>

</html>

-----------------------------------------------------------------
$_SERVER: It will display details about the server.
<html>
 <body>
 <?php
 echo $_SERVER['SERVER_PORT'];
 echo "<br>";
 echo $_SERVER['SERVER_ADDR'];
 echo "<br>";
 echo $_SERVER['SERVER_PROTOCOL'];
 echo "<br>";
 echo $_SERVER['PHP_SELF'];
 echo "<br>";
 echo $_SERVER['SERVER_NAME'];
 echo "<br>";
 echo $_SERVER['HTTP_HOST'];
 echo "<br>";
echo $_SERVER['HTTP_USER_AGENT'];
echo "<br>";
echo $_SERVER['SCRIPT_NAME'];
 ?>
 </body>
</html>



<?php 
$indicesServer = array('PHP_SELF', 
'argv', 
'argc', 
'GATEWAY_INTERFACE', 
'SERVER_ADDR', 
'SERVER_NAME', 
'SERVER_SOFTWARE', 
'SERVER_PROTOCOL', 
'REQUEST_METHOD', 
'REQUEST_TIME', 
'REQUEST_TIME_FLOAT', 
'QUERY_STRING', 
'DOCUMENT_ROOT', 
'HTTP_ACCEPT', 
'HTTP_ACCEPT_CHARSET', 
'HTTP_ACCEPT_ENCODING', 
'HTTP_ACCEPT_LANGUAGE', 
'HTTP_CONNECTION', 
'HTTP_HOST', 
'HTTP_REFERER', 
'HTTP_USER_AGENT', 
'HTTPS', 
'REMOTE_ADDR', 
'REMOTE_HOST', 
'REMOTE_PORT', 
'REMOTE_USER', 
'REDIRECT_REMOTE_USER', 
'SCRIPT_FILENAME', 
'SERVER_ADMIN', 
'SERVER_PORT', 
'SERVER_SIGNATURE', 
'PATH_TRANSLATED', 
'SCRIPT_NAME', 
'REQUEST_URI', 
'PHP_AUTH_DIGEST', 
'PHP_AUTH_USER', 
'PHP_AUTH_PW', 
'AUTH_TYPE', 
'PATH_INFO', 
'ORIG_PATH_INFO') ; 

echo '<table cellpadding="10">' ; 
foreach ($indicesServer as $arg) { 
    if (isset($_SERVER[$arg])) { 
        echo '<tr><td>'.$arg.'</td><td>' . $_SERVER[$arg] . '</td></tr>' ; 
    } 
    else { 
        echo '<tr><td>'.$arg.'</td><td>-</td></tr>' ; 
    } 
} 
echo '</table>' ; 

/* 

That will give you the result of each variable like (if the file is server_indices.php at the root and Apache Web directory is in E:\web) : 

PHP_SELF    /server_indices.php 
argv    - 
argc    - 
GATEWAY_INTERFACE    CGI/1.1 
SERVER_ADDR    127.0.0.1 
SERVER_NAME    localhost 
SERVER_SOFTWARE    Apache/2.2.22 (Win64) PHP/5.3.13 
SERVER_PROTOCOL    HTTP/1.1 
REQUEST_METHOD    GET 
REQUEST_TIME    1361542579 
REQUEST_TIME_FLOAT    - 
QUERY_STRING    
DOCUMENT_ROOT    E:/web/ 
HTTP_ACCEPT    text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8 
HTTP_ACCEPT_CHARSET    ISO-8859-1,utf-8;q=0.7,*;q=0.3 
HTTP_ACCEPT_ENCODING    gzip,deflate,sdch 
HTTP_ACCEPT_LANGUAGE    fr-FR,fr;q=0.8,en-US;q=0.6,en;q=0.4 
HTTP_CONNECTION    keep-alive 
HTTP_HOST    localhost 
HTTP_REFERER    http://localhost/ 
HTTP_USER_AGENT    Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.57 Safari/537.17 
HTTPS    - 
REMOTE_ADDR    127.0.0.1 
REMOTE_HOST    - 
REMOTE_PORT    65037 
REMOTE_USER    - 
REDIRECT_REMOTE_USER    - 
SCRIPT_FILENAME    E:/web/server_indices.php 
SERVER_ADMIN    myemail@personal.us 
SERVER_PORT    80 
SERVER_SIGNATURE    
PATH_TRANSLATED    - 
SCRIPT_NAME    /server_indices.php 
REQUEST_URI    /server_indices.php 
PHP_AUTH_DIGEST    - 
PHP_AUTH_USER    - 
PHP_AUTH_PW    - 
AUTH_TYPE    - 
PATH_INFO    - 
ORIG_PATH_INFO    - 

*/ 
?>