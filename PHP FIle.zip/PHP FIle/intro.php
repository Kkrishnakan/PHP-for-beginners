<!DOCTYPE html>
<html>
<head>
<title></title>
</head>
<body>
<?php
//if($con=mysql_connect("localhost","root",""))
                       // echo   "connected";
            // else 
                       // echo  "Not connected";
            
if(isset($_POST['sub']))
{
$sno=$_POST['txtsno'];
$uname=$_POST['txtuname'];
mysql_connect("localhost","root","");
mysql_select_db("testm");
if(mysql_query("insert into student values('$sno','$uname')"))
echo "Added";
else
echo "Not added";
}
?>
            
<form action ="" method="post">
sno:<input type="text" name="txtsno"><br>
username:<input type="text"  name="txtuname"><br>
<input type="submit" name="sub" value="click">
</form>

</body>
</html>