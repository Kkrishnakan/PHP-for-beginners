<!DOCTYPE html>
<html>
<head>
	<title>expo</title>
</head>
<body>
<?php

$x = 50;
$y = 60;

echo $x ** $y;

?>
</body>
</html>