<!DOCTYPE html>
<html>
<head>
	<title>ass2</title>
</head>
<body>
<?php
$x ['ram']= "75";
$y ['krishna']= "60";

echo "ram marks". $x['ram']."<br/>";
echo "krishna marks".$y['krishna']."<br/>";
?>
</body>
</html>