<!DOCTYPE html>
<html>
<head>
	<title>logical</title>
</head>
<body>
<!-- <?php
# true if the both are true 
$x = 10;  
$y = 5;

if ($x == 10 and $y == 5) {
    echo "Hi this is krishna";
}
?>   -->

<!-- <?php
# true if any one is true
$x = 100;  
$y = 50;

if ($x == 100 or $y == 80) {
    echo "Hi ";
}
?>  -->

<!-- <?php
# if the give statement is true 
$x = 100;  
$y = 50;

if ($x == 100 xor $y == 80) {
    echo "Hello!";
}
?> -->

<!-- <?php
# if the both statements are true 
$x = 100;  
$y = 50;

if ($x == 100 && $y == 50) {
    echo " world!";
}
?>  -->

<!-- <?php
# if any one is true 
$x = 100;  
$y = 50;

if ($x == 100 || $y == 80) {
    echo "this is ||";
}
?>    -->

<?php
# if the condition is true or false 
$x = 100;  

if ($x !== 90) {
    echo "deni istam";
}
?>  


</body>
</html>