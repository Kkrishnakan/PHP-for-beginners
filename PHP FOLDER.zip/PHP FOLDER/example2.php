<!DOCTYPE html>
<html>
<head>
	<title>example2</title>
</head>
<body>
	<?php
	$x = "hi this is code generate all that which is printed in echo and it will return in the out put by localhost and should be save in htdocs";
	$y = "900";
	$z = "5";

	echo "<h2>". $x . "</h2>";
	echo $y * $z;
	?>

</body>
</html>
