<!DOCTYPE html>
<html>
<head>
	<title>elsecondition</title>
</head>
<body>
<?php
$q = 10;


if ($q <= 10) {
	echo 'true';
}
else
{
	echo 'false';
}
?>
</body>
</html>