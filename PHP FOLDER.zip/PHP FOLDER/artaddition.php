<!DOCTYPE html>
<html>
<head>
	<title>addition</title>
</head>
<body>
	<?php
	$x = 10;
	$y = 20;

	echo $x + $y;
	?>
</body>
</html>