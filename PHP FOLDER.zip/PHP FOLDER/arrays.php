<!DOCTYPE html>
<html>
<head>
	<title>example</title>
</head>
<body>
<?php

$x [0]= "one";
$x [1]= "two";
foreach ($x as $value) {
	# code...
	echo "value is $value <br/>";
}
?>
</body>
</html>