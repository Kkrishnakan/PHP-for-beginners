<!DOCTYPE html>
<html>
<head>
	<title>Comparison Operators</title>
</head>
<body>

<!-- <?php
# if the given condition is true 
$x = 100;
$y = "100";

var_dump( $x == $y );
?>
 -->

<!-- <?php
#if the give condition is true but operater is ===
$x = 100;  
$y = "100";

var_dump ($x === $y); 

?>   -->

<!-- <?php
#if the given condition true or false !=

$x = 100;
$y = "401";

var_dump ( $x != $y)

?> -->

<!-- <?php
#<>
$x = 0;  
$y = "0";

var_dump($x <> $y); 
?>  
 -->
<!-- 
<?php

# !==
$x = 2;  
$y = "3";

var_dump($x !== $y); 
?>   -->

<!-- <?php
#greater
$x = 1;
$y = 5;

var_dump($x > $y);
?>   -->

<?php
# >=
$x = 1.0;
$y = 1.0;

var_dump($x >= $y);

?>



</body>
</html>