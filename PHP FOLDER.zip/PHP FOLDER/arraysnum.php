<!DOCTYPE html>
<html>
<head>
	<title>Arrays numaric</title>
</head>
<body>
<?php

$x = array(1,2,3)
foreach ($x as $value){
	# code...
	echo 'x value is $value <br/>';
}

?>

</body>
</html>