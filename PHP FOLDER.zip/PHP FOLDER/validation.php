<!DOCTYPE html>
<html>
<body>

<?php
$p = "Learn PHP";
$j = "W3Schools.com";
$x = 5000;
$y = 4000;

echo "<h2>" . $p . "</h2>";
echo "Study PHP at " . $j . "<br>";
echo $x + $y;
?>

</body>
</html>