<!DOCTYPE html>
<html>
<head>
	<title>if condition</title>
</head>
<body>
<?php
$t = 20;
if ($t < 21){
	# code...
	echo "our lkdflsaf";
}

?>
</body>
</html>