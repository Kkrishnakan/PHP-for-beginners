<!DOCTYPE html>
<html>
<head>
	<title>do while</title>
</head>
<body>
<?php
$x = 1;

    do
{
	echo "number is" .$x."<br>";
		$x ++;
}
while ($x<=6)
?>
</body>
</html>

