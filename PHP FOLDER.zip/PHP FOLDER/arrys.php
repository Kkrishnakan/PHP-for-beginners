<!DOCTYPE html>
<html>
<head>
	<title>arrys example</title>
</head>
<body>

<!-- <?php

#array concepts(union)

$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  

print_r($x + $y); 
?>   -->

<!-- <?php
# it means all the statements should be equal 
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  

var_dump($x == $y);
?>  -->

<!-- <?php
#if the staements are not same then it is false
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  

var_dump($x === $y);
?>  
 -->

<!-- <?php
#may be same or different out put is true 
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  

var_dump($x != $y);
?>   -->

<!-- <?php
#it will return true if x is not y
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  

var_dump($x <> $y);
?>   -->



<?php
$x = array("a" => "red", "b" => "green");  
$y = array("c" => "blue", "d" => "yellow");  

var_dump($x !== $y);
?>  


</body>
</html>