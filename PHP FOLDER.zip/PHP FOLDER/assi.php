<!DOCTYPE html>
<html>
<head>
	<title>all the Assignment Operators</title>
</head>
<body>
<!-- <?php
#adding of elements with +=
$x = 500;
$x += 200;
echo $x ;
?>
 -->
 
<?php
#sub fo two elements -=

$x = 22;
$x -= 10;

echo $x;
?>	

 </body>
</html>