<!DOCTYPE html>
<html>
<title>
	example1
</title>
<body>
	<?php
	$x = "i have ";
	$y ="20 friends";
	echo "$x"."$y"
	?>
</body>
</html>