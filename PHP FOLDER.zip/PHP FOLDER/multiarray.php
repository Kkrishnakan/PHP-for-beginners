<!DOCTYPE html>
<html>
<head>
	<title>multi arrays</title>
</head>
<body>
<?php

$marks = $array{
	"ram" => array{
		"english" => 60;
		"maths" => 65;
		"hindi" => 70;
	}
	"krishna" => array {
		"english" => 73;
		"maths" => 67;
		"hindi" => 49;
	}
};
echo "marks for ram in hindi:"
echo $marks['ram']['hindi']."<br/>";

echo "marks for krishna in maths :"
echo $marks['krishna']['maths']."<br/>"
?>
</body>
</html>