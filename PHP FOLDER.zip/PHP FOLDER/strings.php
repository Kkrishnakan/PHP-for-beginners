<!DOCTYPE html>
<html>
<head>
	<title>strings operation</title>
</head>
<body>

<!-- <?php
# it is usefull in strings 
$k = "hi this is krishna";
$r = " hello world";
echo $k . $r;
?>  
 -->

 <?php

 ?>

</body>
</html>