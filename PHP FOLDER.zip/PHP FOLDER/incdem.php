<!DOCTYPE html>
<html>
<head>
	<title>increment and decrement</title>
</head>
<body>

<!-- <?php
# increment
$x = 10000;  
echo ++$x;
?>   -->

<!-- <?php
# decrement
$x = 1000;  
echo --$x;
?>  
 -->



</body>
</html>