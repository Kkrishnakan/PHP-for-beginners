<!DOCTYPE html>
<html>
<head>
	<title>data type</title>
</head>
<body>
<?php
$x = "hello this is php and here is the value of x <br>";
$y = "here is the value of y";

echo "$x"."$y";

?>
</body>
</html>