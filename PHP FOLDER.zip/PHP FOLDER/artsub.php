<!DOCTYPE html>
<html>
<head>
	<title>sub</title>
</head>
<body>
<?php
$x = 1000;
$y = 500;
 
echo $x - $y;
?>
</body>
</html>