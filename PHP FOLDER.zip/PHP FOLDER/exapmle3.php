<!DOCTYPE html>
<html>
<head>
	<title>example3</title>
</head>
<body>
	<?php
	$x = "this example is for adding  2 numbers in the give required file" ;
	$z = 20;
	$y = 30;
	$d = "sum of total";
		
	echo "$x";
	echo "$d". $z + $y ;
	?>
</body>
</html>