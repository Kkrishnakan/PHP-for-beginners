<!DOCTYPE html>
<html>
<head>
	<title>connection</title>
</head>
<body>
<?php
$con = mysqli_connect("localhost","root","");
if (mysqli_connect_errno())
{
	echo "failed to connect to mySQL:".mysqli_connect_error();
}
else
{
	echo "connected";
}
?>
</body>
</html>