<!DOCTYPE html>
<html>
<head>
	<title>associative</title>
</head>
<body>
<?php

$x = array("ram"=>75 , "krishna"=>85);

echo "ram x". $x ['ram']."<br/>";
echo "krishna x". $x ['krishna']."<br/>";

?>
</body>
</html>